$(function() {


    // 스크롤 애니메이션 시작!
    $('.animate').scrolla({
        mobile: true,        // 모바일 적용 여부
        once: false,         // 스크롤 애니메이션 한 번만 적용 여부
    })


})